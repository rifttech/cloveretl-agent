/*
 * jETeL/CloverETL - Java based ETL application framework.
 * Copyright (c) Javlin, a.s. (info@cloveretl.com)
 *  
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
package org.jetel.component.fileoperation;

import static java.text.MessageFormat.format;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.jetel.component.fileoperation.SimpleParameters.CopyParameters;
import org.jetel.component.fileoperation.SimpleParameters.CreateParameters;
import org.jetel.component.fileoperation.SimpleParameters.DeleteParameters;
import org.jetel.component.fileoperation.SimpleParameters.FileParameters;
import org.jetel.component.fileoperation.SimpleParameters.InfoParameters;
import org.jetel.component.fileoperation.SimpleParameters.ListParameters;
import org.jetel.component.fileoperation.SimpleParameters.MoveParameters;
import org.jetel.component.fileoperation.SimpleParameters.ReadParameters;
import org.jetel.component.fileoperation.SimpleParameters.ResolveParameters;
import org.jetel.component.fileoperation.SimpleParameters.WriteParameters;
import org.jetel.util.ExceptionUtils;

/**
 * @author krivanekm (info@cloveretl.com)
 *         (c) Javlin, a.s. (www.cloveretl.com)
 *
 * @created 28.3.2012
 */
public abstract class AbstractOperationHandler implements IOperationHandler {
	
	protected final PrimitiveOperationHandler simpleHandler;
	protected final RecursiveDeleteHandler deleteHandler;
	protected final WildcardResolutionHandler wildcardHandler;
	protected final FileMetadataHandler fileMetadataProvider;

	public AbstractOperationHandler(PrimitiveOperationHandler simpleHandler) {
		this.simpleHandler = simpleHandler;
		this.deleteHandler = (simpleHandler instanceof RecursiveDeleteHandler) ? (RecursiveDeleteHandler) simpleHandler : null; 
		this.wildcardHandler = (simpleHandler instanceof WildcardResolutionHandler) ? (WildcardResolutionHandler) simpleHandler : null; 
		this.fileMetadataProvider = (simpleHandler instanceof FileMetadataHandler) ? (FileMetadataHandler) simpleHandler : null; 
	}

	private static final CreateParameters CREATE_PARENT_DIRS = new CreateParameters().setMakeParents(true).setDirectory(true);

	private final FileManager manager = FileManager.getInstance();;
	
	protected URI getChildURI(URI parentDir, String child) {
		return URIUtils.getChildURI(parentDir, child);
	}
	
	protected boolean copyInternal(URI sourceUri, URI targetUri, CopyParameters params) throws IOException {
		if (Thread.currentThread().isInterrupted()) {
			throw new IOException(FileOperationMessages.getString("IOperationHandler.interrupted")); //$NON-NLS-1$
		}
		Info source = simpleHandler.info(sourceUri);
		Info target = simpleHandler.info(targetUri);
		if (source == null) {
			throw new FileNotFoundException(MessageFormat.format(FileOperationMessages.getString("IOperationHandler.file_not_found"), sourceUri.toString())); //$NON-NLS-1$
		}
		if (target != null) {
			if (source.getURI().normalize().equals(target.getURI().normalize())) {
				throw new SameFileException(sourceUri, targetUri);
			}
		}
		boolean makeParents = Boolean.TRUE.equals(params.isMakeParents());
		if (source.isDirectory()) {
			if (!params.isRecursive()) {
				throw new IOException(MessageFormat.format(FileOperationMessages.getString("IOperationHandler.cannot_copy_directory"), source.getURI())); //$NON-NLS-1$
			}
			if (target != null && !target.isDirectory()) {
				throw new IOException(format(FileOperationMessages.getString("IOperationHandler.cannot_overwrite_not_a_directory"), source.getURI(), target.getURI())); //$NON-NLS-1$
			}
			if (target == null) {
				if (makeParents) {
					URI parentUri = URIUtils.getParentURI(targetUri);
					create(parentUri, CREATE_PARENT_DIRS);
				}
				if (!simpleHandler.makeDir(targetUri)) {
					throw new IOException(format(FileOperationMessages.getString("IOperationHandler.create_failed"), targetUri)); //$NON-NLS-1$
				}
			}
			boolean success = true;
			for (Info child: listDirectory(sourceUri)) {
				success &= copyInternal(child.getURI(), getChildURI(targetUri, child.getName()), params);
			}
			return success;
		} else {
			if (target != null) {
				if (params.isNoOverwrite()) {
					return true;
				}
				if (params.isUpdate() && (source.getLastModified().compareTo(target.getLastModified()) <= 0)) {
					return true;
				}
			} else if (makeParents) {
				URI parentUri = URIUtils.getParentURI(targetUri);
				create(parentUri, CREATE_PARENT_DIRS);
			}
			return simpleHandler.copyFile(sourceUri, targetUri) != null;
		}
	}
	
	protected void checkSubdir(URI source, URI target) throws IOException {
		String sourcePath = source.normalize().toString();
		String targetPath = target.normalize().toString();
		if (!sourcePath.endsWith(URIUtils.PATH_SEPARATOR)) {
			sourcePath = sourcePath + URIUtils.PATH_SEPARATOR;
		}
		if (targetPath.startsWith(sourcePath)) {
			throw new IOException(MessageFormat.format(FileOperationMessages.getString("IOperationHandler.subdirectory"), target, source)); //$NON-NLS-1$
		}
	}
	
	protected SingleCloverURI copy(URI sourceUri, URI targetUri, CopyParameters params) throws IOException {
		Info sourceInfo = simpleHandler.info(sourceUri);
		if (sourceInfo == null) {
			throw new FileNotFoundException(MessageFormat.format(FileOperationMessages.getString("IOperationHandler.file_not_found"), sourceUri.toString())); //$NON-NLS-1$
		}
		Info targetInfo = simpleHandler.info(targetUri);
		if ((targetInfo != null) && targetInfo.isDirectory()) {
			targetUri = getChildURI(targetUri, sourceInfo.getName());
		} else if (targetUri.toString().endsWith(URIUtils.PATH_SEPARATOR)) {
			if (Boolean.TRUE.equals(params.isMakeParents())) {
				targetUri = getChildURI(targetUri, sourceInfo.getName());
			} else if (!sourceInfo.isDirectory()) {
				throw new IOException(MessageFormat.format(FileOperationMessages.getString("IOperationHandler.not_a_directory"), targetUri)); //$NON-NLS-1$
			}
		}
		if (sourceInfo.isDirectory()) {
			checkSubdir(sourceUri, targetUri);
		}
		return copyInternal(sourceUri, targetUri, params) ? CloverURI.createSingleURI(targetUri) : null;
	}

	@Override
	public SingleCloverURI copy(SingleCloverURI sourceUri, SingleCloverURI targetUri, CopyParameters params)
			throws IOException {
		return copy(sourceUri.toURI(), targetUri.toURI(), params);
	}

	protected boolean moveInternal(URI sourceUri, URI targetUri, MoveParameters params) throws IOException {
		if (Thread.currentThread().isInterrupted()) {
			throw new IOException(FileOperationMessages.getString("IOperationHandler.interrupted")); //$NON-NLS-1$
		}
		Info source = simpleHandler.info(sourceUri);
		Info target = simpleHandler.info(targetUri);
		if (source == null) {
			throw new FileNotFoundException(MessageFormat.format(FileOperationMessages.getString("IOperationHandler.file_not_found"), sourceUri.toString())); //$NON-NLS-1$
		}
		if (target != null) {
			if (source.getURI().normalize().equals(target.getURI().normalize())) {
				throw new SameFileException(sourceUri, targetUri);
			}
		}
		boolean makeParents = Boolean.TRUE.equals(params.isMakeParents());
		if (source.isDirectory()) {
			if (target != null) {
				if (target.isDirectory()) {
					List<URI> children = simpleHandler.list(targetUri);
					if ((children != null) && (children.size() > 0)) {
						throw new IOException(format(FileOperationMessages.getString("IOperationHandler.not_empty"), target.getURI())); //$NON-NLS-1$
					}
					simpleHandler.removeDir(targetUri); // necessary for renameTo()
				} else {
					throw new IOException(format(FileOperationMessages.getString("IOperationHandler.cannot_overwrite_not_a_directory"), source.getURI(), target.getURI())); //$NON-NLS-1$
				}
			} else if (makeParents) {
				URI parentUri = URIUtils.getParentURI(targetUri);
				create(parentUri, CREATE_PARENT_DIRS);
			}
			IOException renameException = null;
			try {
				if (simpleHandler.renameTo(sourceUri, targetUri) != null) {
					return true;
				}
			} catch (IOException ioe) {
				// ignore, just an attempt
				renameException = ioe;
			}
			try {
				if (!simpleHandler.makeDir(targetUri)) {
					throw new IOException(format(FileOperationMessages.getString("IOperationHandler.create_failed"), target.getURI())); //$NON-NLS-1$
				}
				boolean success = true;
				for (Info child: listDirectory(sourceUri)) {
					success &= moveInternal(child.getURI(), getChildURI(targetUri, child.getName()), params);
				}
				return success && simpleHandler.removeDir(sourceUri);
			} catch (IOException ioe) {
				throw ExceptionUtils.addSuppressed(ioe, renameException);
			}
		} else {
			if (target != null) {
				if (params.isNoOverwrite()) {
					return true;
				}
				if (params.isUpdate() && (source.getLastModified().compareTo(target.getLastModified()) <= 0)) {
					return true;
				}
				simpleHandler.deleteFile(targetUri); // necessary for renameTo()
			} else if (makeParents) {
				URI parentUri = URIUtils.getParentURI(targetUri);
				create(parentUri, CREATE_PARENT_DIRS);
			}
			IOException renameException = null;
			try {
				if (simpleHandler.renameTo(sourceUri, targetUri) != null) {
					return true;
				}
			} catch (IOException ioe) {
				renameException = ioe;
				// ignore, just an attempt
			}
			try {
				return (simpleHandler.copyFile(sourceUri, targetUri) != null) && simpleHandler.deleteFile(sourceUri);
			} catch (IOException ioe) {
				throw ExceptionUtils.addSuppressed(ioe, renameException);
			}
		}
	}

	protected SingleCloverURI move(URI sourceUri, URI targetUri, MoveParameters params) throws IOException {
		Info sourceInfo = simpleHandler.info(sourceUri);
		if (sourceInfo == null) {
			throw new FileNotFoundException(MessageFormat.format(FileOperationMessages.getString("IOperationHandler.file_not_found"), sourceUri.toString())); //$NON-NLS-1$
		}
		Info targetInfo = simpleHandler.info(targetUri);
		if ((targetInfo != null) && targetInfo.isDirectory()) {
			targetUri = getChildURI(targetUri, sourceInfo.getName());
		} else if (targetUri.toString().endsWith(URIUtils.PATH_SEPARATOR)) {
			if (Boolean.TRUE.equals(params.isMakeParents())) {
				targetUri = getChildURI(targetUri, sourceInfo.getName());
			} else if (!sourceInfo.isDirectory()) {
				throw new IOException(MessageFormat.format(FileOperationMessages.getString("IOperationHandler.not_a_directory"), targetUri)); //$NON-NLS-1$
			}
		}
		if (sourceInfo.isDirectory()) {
			checkSubdir(sourceUri, targetUri);
		}
		return moveInternal(sourceUri, targetUri, params) ? SingleCloverURI.createSingleURI(targetUri) : null;
	}

	@Override
	public SingleCloverURI move(SingleCloverURI source, SingleCloverURI target, MoveParameters params)
			throws IOException {
		return move(source.toURI(), target.toURI(), params);
	}

	private class DefaultContent implements Content {
		
		private final URI uri;
		
		public DefaultContent(URI uri) {
			this.uri = uri;
		}

		@Override
		public ReadableByteChannel read() throws IOException {
			return simpleHandler.read(uri);
		}
		
		public WritableByteChannel write(boolean append) throws IOException {
			Info info = simpleHandler.info(uri);
			if (info == null) {
				simpleHandler.createFile(uri);
			}
			return append ? simpleHandler.append(uri) : simpleHandler.write(uri);
		}

		@Override
		public WritableByteChannel write() throws IOException {
			return write(false);
		}

		@Override
		public WritableByteChannel append() throws IOException {
			return write(true);
		}
		
	}

	@Override
	public ReadableContent getInput(SingleCloverURI source, ReadParameters params) throws IOException {
		return new DefaultContent(source.toURI());
	}

	@Override
	public WritableContent getOutput(SingleCloverURI target, WriteParameters params) throws IOException {
		return new DefaultContent(target.toURI());
	}
	
	protected boolean delete(URI target, DeleteParameters params) throws IOException {
		if (Thread.currentThread().isInterrupted()) {
			throw new IOException(FileOperationMessages.getString("IOperationHandler.interrupted")); //$NON-NLS-1$
		}
		Info info = simpleHandler.info(target);
		if (info == null) {
			throw new FileNotFoundException(MessageFormat.format(FileOperationMessages.getString("IOperationHandler.file_not_found"), target.toString())); //$NON-NLS-1$
		}
		if (!info.isDirectory() && target.toString().endsWith(URIUtils.PATH_SEPARATOR)) {
			throw new IOException(MessageFormat.format(FileOperationMessages.getString("IOperationHandler.not_a_directory"), target)); //$NON-NLS-1$
		}
		if (info.isDirectory()) {
			if (params.isRecursive()) {
				if (deleteHandler != null) {
					return deleteHandler.removeDirRecursively(target);
				} else {
					for (URI child: simpleHandler.list(target)) {
						delete(child, params);
					}
					return simpleHandler.removeDir(target);
				}
			} else {
				throw new IOException(MessageFormat.format(FileOperationMessages.getString("IOperationHandler.cannot_remove_directory"), target)); //$NON-NLS-1$
			}
		} else {
			return simpleHandler.deleteFile(target);
		}
	}

	@Override
	public SingleCloverURI delete(SingleCloverURI target, DeleteParameters params) throws IOException {
		URI uri = target.toURI().normalize();
		if (delete(uri, params)) {
			return CloverURI.createSingleURI(uri);
		}
		return null;
	}

	@Override
	public List<SingleCloverURI> resolve(SingleCloverURI wildcards, ResolveParameters params) throws IOException {
		if (wildcardHandler == null) {
			return manager.defaultResolve(wildcards);
		}
		
		String uriString = wildcards.toURI().toString();
		if (wildcards.isRelative() || !FileManager.uriHasWildcards(uriString)) {
			return Arrays.asList(wildcards);
		}
		
		List<String> parts = FileManager.getUriParts(uriString);
		URI baseUri = URI.create(parts.get(0));
		Info baseInfo = simpleHandler.info(baseUri);
		if (baseInfo == null) {
			return new ArrayList<SingleCloverURI>(0);
		}
		List<URI> bases = Arrays.asList(baseUri);
		for (Iterator<String> it = parts.listIterator(1); it.hasNext(); ) {
			String part = it.next();
			List<URI> nextBases = new ArrayList<>(bases.size());
			boolean hasPathSeparator = part.endsWith(URIUtils.PATH_SEPARATOR);
			if (hasPathSeparator) {
				part = part.substring(0, part.length()-1);
			}
			for (URI i: bases) {
				nextBases.addAll(expand(i, part, it.hasNext() || hasPathSeparator));
			}
			bases = nextBases;
		}
		
		List<SingleCloverURI> result = new ArrayList<SingleCloverURI>(bases.size());
		for (URI u: bases) {
			result.add(CloverURI.createSingleURI(u));
		}
		return result;
	}

	private List<URI> expand(URI base, String part, boolean directory) throws IOException {
		if (base == null) {
			throw new NullPointerException("base"); //$NON-NLS-1$
		}
		Info baseInfo = simpleHandler.info(base);
		if ((baseInfo == null) || !baseInfo.isDirectory()) {
			throw new IllegalArgumentException(format(FileOperationMessages.getString("FileManager.not_a_directory"), base)); //$NON-NLS-1$
		}
		if (FileManager.hasWildcards(part)) {
			part = URIUtils.urlDecode(part);
			return wildcardHandler.list(base, part, directory);
		} else {
			URI child = URIUtils.getChildURI(base, URI.create(part));
			Info childInfo = simpleHandler.info(child);
			if (childInfo != null) {
				return Arrays.asList(child);
			} else {
				return Collections.emptyList();
			}
		}
	}

	/**
	 * Should be overridden if it is easy for the {@link PrimitiveOperationHandler}
	 * to return {@link Info} instead of {@link URI}.
	 * 
	 * @param uri
	 * @return
	 * @throws IOException
	 */
	protected List<Info> listDirectory(URI uri) throws IOException {
		if (fileMetadataProvider != null) {
			return fileMetadataProvider.listFiles(uri);
		}
		
		List<URI> children = simpleHandler.list(uri); 
		List<Info> result = new ArrayList<Info>(children.size());
		for (URI child: children) {
			Info childInfo = simpleHandler.info(child);
			result.add(childInfo);
		}
		return result;
	}
	
	protected List<Info> list(URI uri, ListParameters params) throws IOException {
		if (Thread.currentThread().isInterrupted()) {
			throw new IOException(FileOperationMessages.getString("IOperationHandler.interrupted")); //$NON-NLS-1$
		}
		Info info = simpleHandler.info(uri);
		if (info == null) {
			throw new FileNotFoundException(MessageFormat.format(FileOperationMessages.getString("IOperationHandler.file_not_found"), uri.toString())); //$NON-NLS-1$
		}
		if (uri.toString().endsWith(URIUtils.PATH_SEPARATOR) && !info.isDirectory()) {
			throw new FileNotFoundException(format(FileOperationMessages.getString("IOperationHandler.not_a_directory"), uri)); //$NON-NLS-1$
		}
		if (info.isDirectory()) {
			List<Info> children = listDirectory(uri); 
			List<Info> result = new ArrayList<>(children.size());
			for (Info child: children) {
				result.add(child);
				if (params.isRecursive() && child.isDirectory()) {
					result.addAll(list(child.getURI(), params));
				}
			}
			return result;
		} else {
			return Arrays.asList(info);
		}
	}

	@Override
	public List<Info> list(SingleCloverURI parent, ListParameters params) throws IOException {
		return list(parent.toURI(), params);
	}

	@Override
	public Info info(SingleCloverURI target, InfoParameters params) throws IOException {
		return simpleHandler.info(target.toURI());
	}
	
	protected boolean create(URI uri, CreateParameters params) throws IOException {
		if (Thread.currentThread().isInterrupted()) {
			throw new IOException(FileOperationMessages.getString("IOperationHandler.interrupted")); //$NON-NLS-1$
		}
		Boolean isDirectory = params.isDirectory();
		boolean createDirectory = Boolean.TRUE.equals(isDirectory);
		boolean createParents = Boolean.TRUE.equals(params.isMakeParents());
		Date lastModified = params.getLastModified();
		Info fileInfo = simpleHandler.info(uri);
		boolean success = true;
		if (fileInfo == null) { // does not exist
			if (createParents) {
				URI parentUri = URIUtils.getParentURI(uri);
				create(parentUri, params.clone().setDirectory(true));
			}
			if (createDirectory) {
				success = simpleHandler.makeDir(uri);
			} else {
				success = simpleHandler.createFile(uri);
			}
			if (lastModified != null) {
				success &= simpleHandler.setLastModified(uri, lastModified);
			}
		} else {
			if ((isDirectory != null) && (!isDirectory.equals(fileInfo.isDirectory()))) {
				throw new IOException(MessageFormat.format(isDirectory ? FileOperationMessages.getString("IOperationHandler.exists_not_directory") : FileOperationMessages.getString("IOperationHandler.exists_not_file"), uri)); //$NON-NLS-1$ //$NON-NLS-2$
			}
			if (lastModified != null) {
				success &= simpleHandler.setLastModified(uri, lastModified);
			} else {
				simpleHandler.setLastModified(uri, new Date());
			}
		}
		return success;
	}

	@Override
	public SingleCloverURI create(SingleCloverURI target, CreateParameters params) throws IOException {
		URI uri = target.toURI().normalize();
		if (create(uri, params)) {
			return CloverURI.createSingleURI(uri);
		}
		return null;
	}

	@Override
	public File getFile(SingleCloverURI uri, FileParameters params) throws IOException {
		throw new UnsupportedOperationException();
	}

	@Override
	public String toString() {
		return String.format("AbstractOperationHandler (%s)", simpleHandler); //$NON-NLS-1$
	}
	
	

}
